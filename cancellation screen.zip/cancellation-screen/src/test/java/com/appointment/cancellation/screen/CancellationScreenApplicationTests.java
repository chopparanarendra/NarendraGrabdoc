package com.appointment.cancellation.screen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CancellationScreenApplicationTests {

	@Test
	void contextLoads() {
	}

}
