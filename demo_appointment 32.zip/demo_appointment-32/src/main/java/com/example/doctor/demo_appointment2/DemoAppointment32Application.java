package com.example.doctor.demo_appointment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAppointment32Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoAppointment32Application.class, args);
	}

}
