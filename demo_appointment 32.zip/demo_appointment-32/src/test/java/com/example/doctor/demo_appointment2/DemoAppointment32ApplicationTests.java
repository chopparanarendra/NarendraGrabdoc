package com.example.doctor.demo_appointment2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAppointment32ApplicationTests {

	@Test
	void contextLoads() {
	}

}
